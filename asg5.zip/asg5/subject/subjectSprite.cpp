#include <unistd.h>
#include "subjectSprite.h"
#include "smartSprite.h"
#include "gamedata.h"
#include "renderContext.h"
#include "clock.h"



void SubjectSprite::advanceFrame(Uint32 ticks) {
	timeSinceLastFrame += ticks;
	if (timeSinceLastFrame > frameInterval) {
    currentFrame = (currentFrame+1) % numberOfFrames;
		timeSinceLastFrame = 0;
	}
}

SubjectSprite::SubjectSprite( const std::string& name) :
  Drawable(name, 
           Vector2f(Gamedata::getInstance().getXmlInt(name+"/startLoc/x"), 
                    Gamedata::getInstance().getXmlInt(name+"/startLoc/y")), 
           Vector2f(Gamedata::getInstance().getXmlInt(name+"/speedX"),
                    Gamedata::getInstance().getXmlInt(name+"/speedY"))
           ),
//images( ImageFactory::getInstance()->getImages(name) ),
  imagesRight( ImageFactory::getInstance().getImages(name) ),
  imagesLeft( ImageFactory::getInstance().getImages(name + "Left") ),
  imagesExplode( ImageFactory::getInstance().getImages("explosion1") ),
  images( imagesRight ),
  observers(),
  
  currentFrame(0),
  numberOfFrames( Gamedata::getInstance().getXmlInt(name+"/frames") ),
  facing(RIGHT),
  frameInterval( Gamedata::getInstance().getXmlInt(name+"/frameInterval")),
  timeSinceLastFrame( 0 ),
  bulletName(Gamedata::getInstance().getXmlStr(name+"/bulletName") ),
  bulletInterval(Gamedata::getInstance().getXmlInt(bulletName+"/frameSpeed") ),
  timeSinceLastBullet(0),
  minBulletSpeed(Gamedata::getInstance().getXmlInt(bulletName+"/min")),
  bullets(bulletName),
  
  worldWidth(Gamedata::getInstance().getXmlInt("world/width")),
  worldHeight(Gamedata::getInstance().getXmlInt("world/height")),
  initialVelocity(getVelocity())
{ }

SubjectSprite::SubjectSprite(const SubjectSprite& s) :
  Drawable(s),
  imagesRight(s.imagesRight), 
  imagesLeft(s.imagesLeft),
  imagesExplode(s.imagesExplode),
  images(s.images),
  observers( s.observers ),
   
  currentFrame(s.currentFrame),
  numberOfFrames( s.numberOfFrames ),
  facing(RIGHT),
  
  frameInterval( s.frameInterval ),
  timeSinceLastFrame( s.timeSinceLastFrame ),

  bulletName(s.bulletName),
  bulletInterval(s.bulletInterval),
  timeSinceLastBullet(s.timeSinceLastBullet),
  minBulletSpeed(s.minBulletSpeed),
  bullets(s.bullets),
  

  worldWidth( s.worldWidth ),
  worldHeight( s.worldHeight ),
  initialVelocity( s.initialVelocity )
  
  { }

SubjectSprite& SubjectSprite::operator=(const SubjectSprite& s) {
  Drawable::operator=(s);
  images = (s.images);
  currentFrame = (s.currentFrame);
  numberOfFrames = ( s.numberOfFrames );
  frameInterval = ( s.frameInterval );
  timeSinceLastFrame = ( s.timeSinceLastFrame );
  worldWidth = ( s.worldWidth );
  worldHeight = ( s.worldHeight );
  initialVelocity = ( s.initialVelocity );
  return *this;
}

void SubjectSprite::shoot(){
  if(timeSinceLastBullet > bulletInterval) {
     Vector2f vel = getVelocity();
     float x;
     float y = getY() + getScaledHeight()/4;
     if ( vel[0] > 0) {
	x = getX() + getScaledWidth();
	vel[0] += minBulletSpeed;
     }

     else if ( vel[0] < 0) {
	x = getX();
        vel[0] -= minBulletSpeed;
     }
     else if (facing == RIGHT) {
	x = getX() + getScaledWidth();
        vel[0] += minBulletSpeed;
     }
     else if ( facing == LEFT) {
	x = getX();
        vel[0] -= minBulletSpeed;
     }
     bullets.shoot( Vector2f(x, y), vel );
     timeSinceLastBullet = 0;
  }
}

void SubjectSprite::draw() const { 
  bullets.draw();
  images[currentFrame]->draw(getX(), getY(), getScale());
 
}

void SubjectSprite::stop() { 
  setVelocity( Vector2f(0, 0) );
}

void SubjectSprite::right() { 
  if ( getX() < worldWidth-getScaledWidth()) {
    setVelocityX(initialVelocity[0]);
  }
  images = imagesRight;
  facing = RIGHT;
} 

void SubjectSprite::left()  { 
  if ( getX() > 0) {
    setVelocityX(-initialVelocity[0]);
  }
  images = imagesLeft;
  facing = LEFT;
} 

void SubjectSprite::up()    { 
  if ( getY() > 0) {
    setVelocityY( -initialVelocity[1] );
  }
  
} 
void SubjectSprite::down()  { 
  if ( getY() < worldHeight-getScaledHeight()) {
    setVelocityY( initialVelocity[1] );
  }
}

void SubjectSprite::explode()  { 
 
  exploded = true;
  frameInterval = ( 1000 );
  images = imagesExplode;
}

void SubjectSprite::detach( SmartSprite* o ) {
  std::list<SmartSprite*>::iterator ptr = observers.begin();
  while ( ptr != observers.end() ) {
    if ( *ptr == o ) {
      ptr = observers.erase(ptr);
      return;
    }
    ++ptr;
  }
}

void SubjectSprite::update(Uint32 ticks) { 
  
  advanceFrame(ticks);
  timeSinceLastBullet += ticks;
  bullets.update(ticks);
  Vector2f incr = getVelocity() * static_cast<float>(ticks) * 0.001;
  setPosition(getPosition() + incr);
  
  if(exploded) {
    images = imagesRight;
    frameInterval = Gamedata::getInstance().getXmlInt("BatRight/frameInterval");
  }
  
  if ( getY() < 0) {
    setVelocityY( fabs( getVelocityY() ) );
  }
  if ( getY() > worldHeight-getScaledHeight()) {
    setVelocityY( -fabs( getVelocityY() ) );
  }

  if ( getX() < 0) {
    setVelocityX( fabs( getVelocityX() ) );
    images = imagesRight;
    facing = RIGHT;
  }
  if ( getX() > worldWidth-getScaledWidth()) {
    setVelocityX( -fabs( getVelocityX() ) );
    images = imagesLeft;
    facing = LEFT;
  }  
  std::list<SmartSprite*>::iterator ptr = observers.begin();
  while ( ptr != observers.end() ) {
	(*ptr)->setPlayerPos(getPosition());
        ++ptr;
  }
  stop();
}
