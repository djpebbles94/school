#include <iostream>
#include <cmath>
#include "ioMod.h"
#include "imageFactory.h"

#include "bullets.h"
#include "gamedata.h"

Bullets::~Bullets() {
 
}

CollisionStrategy* getStrategy(const string& name) {
  std::string sName = Gamedata::getInstance().getXmlStr(name+"/strategy");
  if(sName == "midpoint") return new MidPointCollisionStrategy;
  if(sName == "rectangular") return new RectangularCollisionStrategy;
  if(sName == "perpixel") return new PerPixelCollisionStrategy;
  throw std::string("No Strat");
}

Bullets::Bullets(const std::string& n) : 
  name(n),
  strategy(getStrategy(name)),
  myVelocity(
    Gamedata::getInstance().getXmlInt(name+"/speedX"),
    Gamedata::getInstance().getXmlInt(name+"/speedY")
  ),
 // bulletImages( ImageFactory::getInstance().getImages(name) ),
  bulletList(),
  freeList()  
{ }

Bullets::Bullets(const Bullets& b) :
  name(b.name),
 strategy(b.strategy),
  myVelocity(b.myVelocity),
 // bulletImages(b.bulletImages),
  bulletList(b.bulletList),
  freeList(b.freeList)
 
{ }

void Bullets::shoot(const Vector2f& pos, const Vector2f& objVel) {
  if( freeList.empty() ){
     Bullet b ( name, pos, objVel );
     bulletList.push_back(b);
  }
  else{
     Bullet b = freeList.front();
     freeList.pop_front();
     b.reset();
     b.setVelocity(objVel);
     b.setPosition(pos);
     bulletList.push_back( b );
  
  }
}
bool Bullets::collided(const Drawable* obj) const {
  for(const auto& bullet : bulletList) {
     if(strategy->execute(bullet, *obj) ){
       return true;
     }
  }
  return false;
}

void Bullets::draw() const {
  for ( const auto& bullet : bulletList ){
     bullet.draw();
  }
}

void Bullets::update(Uint32 ticks) {
  std::list<Bullet>::iterator ptr = bulletList.begin();
  while (ptr != bulletList.end()){
	ptr->update(ticks);
	if(ptr->goneTooFar()) {
	   freeList.push_back(*ptr);
   	   ptr = bulletList.erase(ptr);
	}
 	else ++ptr;
  }


}










