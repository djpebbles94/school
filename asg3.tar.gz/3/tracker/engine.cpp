#include <iostream>
#include <algorithm>
#include <sstream>
#include <string>
#include <random>
#include <iomanip>
#include "sprite.h"
#include "multisprite.h"
#include "twmsprite.h"
#include "gamedata.h"
#include "engine.h"
#include "frameGenerator.h"

Engine::~Engine() { 
  for(auto& i : vec){
	delete i;
  }
/*
  delete vec[0];
  delete vec[1];
  delete vec[2];
  delete vec[3];
  delete vec[4];
  delete vec[5];
  delete vec[6];
  delete vec[7];
  delete vec[8];
  delete vec[9];
  delete vec[10];
  delete vec[11];
*/
  std::cout << "Terminating program" << std::endl;
}

Engine::Engine() :
  rc( RenderContext::getInstance() ),
  io( IoMod::getInstance() ),
  clock( Clock::getInstance() ),
  renderer( rc->getRenderer() ),
  wind("wind", Gamedata::getInstance().getXmlInt("wind/factor") ),
  cell("cell", Gamedata::getInstance().getXmlInt("cell/factor") ),
  bars("bars", Gamedata::getInstance().getXmlInt("bars/factor") ),
  
  viewport( Viewport::getInstance() ),
 
  vec(),	
  currentSprite(0),
  makeVideo( false )
{
  
  vec.reserve(Gamedata::getInstance().getXmlInt("fb/numSprites")+1);
  for(int i = 0; i < Gamedata::getInstance().getXmlInt("fb/numSprites"); i++){
	vec.emplace_back(new Sprite("Fireball"));
  }
  vec.emplace_back(new MultiSprite("Bat"));
  vec.emplace_back(new TWMSprite("BatRight"));

  Viewport::getInstance().setObjectToTrack(vec[currentSprite]);
  std::cout << "Loading complete" << std::endl;
}

void Engine::draw() const {
  wind.draw();

  cell.draw();


  //draw all of the sprites in the vector
  for(auto& i : vec){
	i->draw();
  }

  //draw the cell bars
  bars.draw();
  
  std::stringstream st;
  st << clock.getFps();
  std::string frames(st.str());
  io.writeText(frames, 35, 60);


  std::string name("Daniel");
  io.writeText(name, 15, 530);
  
  viewport.draw();
  SDL_RenderPresent(renderer);
}

void Engine::update(Uint32 ticks) {
  
  //update all of the sprites in a vector
  for(auto& i : vec){
	i->update(ticks);
  }

  //update backgrounds
  wind.update();
  cell.update();
  bars.update();
  
  
  viewport.update(); // always update viewport last
}

void Engine::switchSprite(){
  ++currentSprite;
  currentSprite = currentSprite % Gamedata::getInstance().getXmlInt("fb/numSprites") + 2;
 
    Viewport::getInstance().setObjectToTrack(vec[currentSprite]);
  
}

void Engine::play() {
  SDL_Event event;
  const Uint8* keystate;
  bool done = false;
  Uint32 ticks = clock.getElapsedTicks();
  FrameGenerator frameGen;

  while ( !done ) {
    // The next loop polls for events, guarding against key bounce:
    while ( SDL_PollEvent(&event) ) {
      keystate = SDL_GetKeyboardState(NULL);
      if (event.type ==  SDL_QUIT) { done = true; break; }
      if(event.type == SDL_KEYDOWN) {
        if (keystate[SDL_SCANCODE_ESCAPE] || keystate[SDL_SCANCODE_Q]) {
          done = true;
          break;
        }
        if ( keystate[SDL_SCANCODE_P] ) {
          if ( clock.isPaused() ) clock.unpause();
          else clock.pause();
        }
        if ( keystate[SDL_SCANCODE_T] ) {
          switchSprite();
        }
        if (keystate[SDL_SCANCODE_F4] && !makeVideo) {
          std::cout << "Initiating frame capture" << std::endl;
          makeVideo = true;
        }
        else if (keystate[SDL_SCANCODE_F4] && makeVideo) {
          std::cout << "Terminating frame capture" << std::endl;
          makeVideo = false;
        }
      }
    }

    // In this section of the event loop we allow key bounce:

    ticks = clock.getElapsedTicks();
    if ( ticks > 0 ) {
      clock.incrFrame();
      draw();
      update(ticks);
      if ( makeVideo ) {
        frameGen.makeFrame();
      }
    }
  }
}
