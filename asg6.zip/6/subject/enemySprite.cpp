#include <cmath>
#include <random>
#include <functional>
#include "enemySprite.h"
#include "gamedata.h"
#include "renderContext.h"

float Edistance(float x1, float y1, float x2, float y2) {
  float x = x1-x2;
  float y = y1-y2;
  return hypot(x, y);
}

void EnemySprite::goLeft()  { setVelocityX( -abs(getVelocityX()) );  }
void EnemySprite::goRight() { setVelocityX( fabs(getVelocityX()) );  }
void EnemySprite::goUp()    { setVelocityY( -fabs(getVelocityY()) ); }
void EnemySprite::goDown()  { setVelocityY( fabs(getVelocityY()) );  }


EnemySprite::EnemySprite(const std::string& name, const Vector2f& pos, 
  int w, int h) :
  TWMSprite(name),
  playerPos(pos),
  playerWidth(w),
  playerHeight(h),
  currentMode(NORMAL),
  safeDistance(Gamedata::getInstance().getXmlFloat(name+"/safeDistance"))
{}


EnemySprite::EnemySprite(const EnemySprite& s) : 
  TWMSprite(s),
  playerPos(s.playerPos),
  playerWidth(s.playerWidth),
  playerHeight(s.playerHeight),
  currentMode(s.currentMode),
  safeDistance(s.safeDistance)
{}

void EnemySprite::update(Uint32 ticks) { 
  TWMSprite::update(ticks);
  float x= getX()+getImage()->getWidth()/2;
  float y= getY()+getImage()->getHeight()/2;
  float ex= playerPos[0]+playerWidth/2;
  float ey= playerPos[1]+playerHeight/2;
  float distanceToEnemy = ::Edistance( x, y, ex, ey );

  if  ( currentMode == NORMAL ) {
    if(distanceToEnemy < safeDistance) currentMode = ATTACK;
  }
  else if  ( currentMode == ATTACK ) {
    if(distanceToEnemy > safeDistance) currentMode=NORMAL;
    else {
      if ( x > ex ){
	goLeft();
	images = imagesLeft;
      }
      if ( x < ex ){
	goRight();
	images = imagesRight;
      }
      if ( y > ey ) goUp();
      if ( y < ey ) goDown();
    }
  }
}
