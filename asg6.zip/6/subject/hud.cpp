#include <sstream>
#include <SDL2/SDL.h>
#include <iomanip>
#include <iostream>
#include <algorithm>
#include <sstream>
#include <string>
#include <random>
#include "hud.h"
#include "gamedata.h"
#include "ioMod.h"


Hud& Hud::getInstance() {
  static Hud hud;
  return hud;
}

Hud::Hud():
  //text(Gamedata::getInstance().getXmlStr("Hud/text")),
  height(Gamedata::getInstance().getXmlInt("Hud/height")),
  width(Gamedata::getInstance().getXmlInt("Hud/width")),
  HudPlacement(Vector2f(Gamedata::getInstance().getXmlInt("Hud/location/x"), Gamedata::getInstance().getXmlInt("Hud/location/y"))),
  active(true),
  color({255, 255, 255, 255/2}),
  textColor({0,0,0,0})
{}

void Hud::draw(){
  if(isActive()){
    SDL_Rect r;
    std::ostringstream screen;
    r.x = getLocation()[0];
    r.y = getLocation()[1];
    r.w = getWidth();
    r.h = getHeight();
    SDL_Renderer* rend = IOmod::getInstance().getRenderer();
    SDL_SetRenderDrawBlendMode(rend, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(rend, color.r, color.g, color.b, color.a);
    SDL_RenderFillRect(rend, &r);
    //screen << getText();

    
    screen << Gamedata::getInstance().getXmlStr("Hud/one");
    IOmod::getInstance().writeText(screen.str(), getTextColor(), getLocation()[0], getLocation()[1]+20);

    screen.clear();
    screen.str("");
    screen <<  Gamedata::getInstance().getXmlStr("Hud/two");
    IOmod::getInstance().writeText(screen.str(), getTextColor(), getLocation()[0], getLocation()[1]+60);

    screen.clear();
    screen.str("");
    screen <<  Gamedata::getInstance().getXmlStr("Hud/three");
    IOmod::getInstance().writeText(screen.str(), getTextColor(), getLocation()[0], getLocation()[1]+160);

    screen.clear();
    screen.str("");
    screen <<  Gamedata::getInstance().getXmlStr("Hud/four");
    IOmod::getInstance().writeText(screen.str(), getTextColor(), getLocation()[0], getLocation()[1]+200);

    screen.clear();
    screen.str("");
    screen <<  Gamedata::getInstance().getXmlStr("Hud/five");
    IOmod::getInstance().writeText(screen.str(), getTextColor(), getLocation()[0], getLocation()[1]+240);

    screen.clear();
    screen.str("");
    screen <<  Gamedata::getInstance().getXmlStr("Hud/six");
    IOmod::getInstance().writeText(screen.str(), getTextColor(), getLocation()[0], getLocation()[1]+280);

    screen.clear();
    screen.str("");
    screen <<  Gamedata::getInstance().getXmlStr("Hud/seven");
    IOmod::getInstance().writeText(screen.str(), getTextColor(), getLocation()[0], getLocation()[1]+320);
    
    screen.clear();
    screen.str("");
    screen <<  Gamedata::getInstance().getXmlStr("Hud/eight");
    IOmod::getInstance().writeText(screen.str(), getTextColor(), getLocation()[0], getLocation()[1]+360);

/*IOmod::getInstance().writeText(screen.str(), getTextColor(), getLocation()[0]+250, getLocation()[1]+20);*/
  }
}


