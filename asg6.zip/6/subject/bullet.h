#ifndef BULLET__H
#define BULLET__H

#include <iostream>
#include "sprite.h"

class Bullet : public Sprite {
public:
   Bullet( const std::string&, const Vector2f&, const Vector2f& );
   Bullet(const Bullet&);
   virtual void update(Uint32 ticks);
   bool goneTooFar() const { return tooFar; }
   void reset();

private:
  float distance;
  float maxDistance;
  bool tooFar;
  Bullet& operator=(const Bullet&);

};
#endif
