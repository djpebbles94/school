#ifndef ENEMYSPRITE__H
#define ENEMYSPRITE__H
#include <string>
#include "twmsprite.h"

class EnemySprite : public TWMSprite {
public:
  EnemySprite(const std::string&, const Vector2f& pos, int w, int h);
  EnemySprite(const EnemySprite&);
  virtual ~EnemySprite() { } 

  virtual void update(Uint32 ticks);
  void setPlayerPos(const Vector2f& p) { playerPos = p; }

private:
  enum MODE {NORMAL, ATTACK};
  Vector2f playerPos;
  int playerWidth;
  int playerHeight;
  MODE currentMode;
  float safeDistance;

  void goLeft();
  void goRight();
  void goUp();
  void goDown();
};
#endif
