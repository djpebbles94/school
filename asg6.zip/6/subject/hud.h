#ifndef __HUD_H__
#define __HUD_H__

#include <SDL2/SDL.h>
#include <string.h>

#include "vector2f.h"


class Hud{
public:
   static Hud& getInstance();

   //const std::string& getText() const {return text;}	//might need const
   bool isActive(){return active;}
   int getHeight() const {return height;}
   int getWidth() const {return width;}
   const Vector2f getLocation() const {return HudPlacement;}
   SDL_Color getHudColor(){return color;}
   SDL_Color getTextColor(){return textColor;}

   void setHeight(int h){height=h;}
   void setWidth(int w){width=w;}
   void setLocation(Vector2f HudP){HudPlacement = HudP;}
   //void setText(std::string& t){text = t;}
   void setActive(bool act){active = act;}
   void setColors(const SDL_Color hudC){color = hudC;}
   void setTxtColor(const SDL_Color txt){textColor = txt;}

   void draw();

private:
   //std::string text;
   int height;
   int width;
   Vector2f HudPlacement;
 
   bool active;
   SDL_Color color;
   SDL_Color textColor;

   Hud();
   Hud& operator=(const Hud&);
   Hud(const Hud&);
};
#endif
